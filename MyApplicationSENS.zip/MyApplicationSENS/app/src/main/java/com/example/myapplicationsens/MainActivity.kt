package com.example.myapplicationsens


import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp



class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(
                modifier = Modifier.fillMaxSize(),

            ) {
                czujniktemp()
            }

        }
    }
}


@Composable
fun czujniktemp() {

    val ctx = LocalContext.current


    val sensorManager: SensorManager = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager


    val temperatureSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)


    val sensorStatus = remember {
        mutableStateOf("")
    }

    var color = remember { mutableStateOf(Color.Black ) }


    val temperauteSensorEventListener = object : SensorEventListener {
        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {

        }


        override fun onSensorChanged(event: SensorEvent) {

            if (event.sensor.type == Sensor.TYPE_AMBIENT_TEMPERATURE) {

                if (event.values[0] < 0f) {

                    sensorStatus.value = "Zimno! Dokładnie: ${event.values[0]} stopni Celsujsza"
                    color.value = Color.Blue
                } else {

                    sensorStatus.value = "Ciepło! Dokładnie: ${event.values[0]} stopni Celsjusza"
                    color.value = Color.Red
                }

            }
        }

    }
    sensorManager.registerListener(

        temperauteSensorEventListener,

        temperatureSensor,

        SensorManager.SENSOR_DELAY_NORMAL
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .fillMaxHeight()
            .fillMaxWidth()
            .padding(5.dp),
        horizontalAlignment = Alignment.CenterHorizontally, //wysrodkowanie
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Jak jest ?",
            color = color.value,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Default,
            fontSize = 45.sp, modifier = Modifier.padding(5.dp)
        )


        Text(
            text = sensorStatus.value,
            color = color.value,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Default,
            fontSize = 20.sp, modifier = Modifier.padding(5.dp)
        )

    }
}